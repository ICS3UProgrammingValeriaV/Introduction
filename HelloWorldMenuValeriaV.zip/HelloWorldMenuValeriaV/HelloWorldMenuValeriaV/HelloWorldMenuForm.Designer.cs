﻿namespace HelloWorldMenuValeriaV
{
    partial class frmHelloWorldMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblHelloWorldMenu = new System.Windows.Forms.Label();
            this.mnuProgramm = new System.Windows.Forms.MenuStrip();
            this.hekpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuProgramm.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblHelloWorldMenu
            // 
            this.lblHelloWorldMenu.AutoSize = true;
            this.lblHelloWorldMenu.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.lblHelloWorldMenu.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblHelloWorldMenu.Font = new System.Drawing.Font("Swis721 BdCnOul BT", 60F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHelloWorldMenu.ForeColor = System.Drawing.SystemColors.MenuBar;
            this.lblHelloWorldMenu.Location = new System.Drawing.Point(265, 58);
            this.lblHelloWorldMenu.Name = "lblHelloWorldMenu";
            this.lblHelloWorldMenu.Size = new System.Drawing.Size(611, 99);
            this.lblHelloWorldMenu.TabIndex = 0;
            this.lblHelloWorldMenu.Text = "Hello World Menu";
            // 
            // mnuProgramm
            // 
            this.mnuProgramm.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.hekpToolStripMenuItem});
            this.mnuProgramm.Location = new System.Drawing.Point(0, 0);
            this.mnuProgramm.Name = "mnuProgramm";
            this.mnuProgramm.Size = new System.Drawing.Size(1158, 24);
            this.mnuProgramm.TabIndex = 1;
            this.mnuProgramm.Text = "menuStrip1";
            // 
            // hekpToolStripMenuItem
            // 
            this.hekpToolStripMenuItem.Name = "hekpToolStripMenuItem";
            this.hekpToolStripMenuItem.Size = new System.Drawing.Size(50, 20);
            this.hekpToolStripMenuItem.Text = "Menu";
            this.hekpToolStripMenuItem.Click += new System.EventHandler(this.hekpToolStripMenuItem_Click);
            // 
            // frmHelloWorldMenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.ClientSize = new System.Drawing.Size(1158, 591);
            this.Controls.Add(this.lblHelloWorldMenu);
            this.Controls.Add(this.mnuProgramm);
            this.MainMenuStrip = this.mnuProgramm;
            this.Name = "frmHelloWorldMenu";
            this.Text = "HelloWorldMenu, by ValeriaV";
            this.mnuProgramm.ResumeLayout(false);
            this.mnuProgramm.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblHelloWorldMenu;
        private System.Windows.Forms.MenuStrip mnuProgramm;
        private System.Windows.Forms.ToolStripMenuItem hekpToolStripMenuItem;
    }
}

